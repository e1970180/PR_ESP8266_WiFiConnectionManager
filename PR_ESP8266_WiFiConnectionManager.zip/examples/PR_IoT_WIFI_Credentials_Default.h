#pragma once


#define		WIFI_ssid_DEFAULT			"Guest"
#define		WIFI_password_DEFAULT		"123456789"